import 'package:flutter/material.dart';

import '../../services/auth_service.dart';
import '../../services/profile_service.dart';

class ConnectPartnerScreen extends StatefulWidget {
  const ConnectPartnerScreen({super.key});

  @override
  State<ConnectPartnerScreen> createState() => _ConnectPartnerScreenState();
}

class _ConnectPartnerScreenState extends State<ConnectPartnerScreen> {
  final ProfileService _profileService = ProfileService();
  final AuthService _authService = AuthService();

  final TextEditingController codeController = TextEditingController();

  bool isLoading = true;
  String myInviteCode = '';

  @override
  void initState() {
    super.initState();
    loadInviteCode();
  }

  Future<void> loadInviteCode() async {
    final user = _authService.currentUser;

    if (user == null) return;

    final profile = await _profileService.getProfile(user.uid);

    if (profile != null) {
      setState(() {
        myInviteCode = profile['inviteCode'] ?? '';
        isLoading = false;
      });
    }
  }

  Future<void> connectPartner() async {
    final user = _authService.currentUser;

    if (user == null) return;

    final code = codeController.text.trim().toUpperCase();

    if (code.isEmpty) {
      showMessage("Enter an invite code.");
      return;
    }

    if (code == myInviteCode) {
      showMessage("You can't connect with yourself.");
      return;
    }

    final partner = await _profileService.findPartnerByCode(code);

    if (partner == null) {
      showMessage("Invite code not found.");
      return;
    }

    await _profileService.connectPartners(
      currentUid: user.uid,
      partnerUid: partner['uid'],
    );

    if (!mounted) return;

    showMessage("❤️ Partner connected successfully!");

    Navigator.pop(context);
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Connect Partner"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              "Your Invite Code",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            SelectableText(
              myInviteCode,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                letterSpacing: 4,
              ),
            ),

            const SizedBox(height: 40),

            TextField(
              controller: codeController,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                labelText: "Partner Invite Code",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 30),

            ElevatedButton.icon(
              onPressed: connectPartner,
              icon: const Icon(Icons.favorite),
              label: const Text("Connect ❤️"),
            ),
          ],
        ),
      ),
    );
  }
}