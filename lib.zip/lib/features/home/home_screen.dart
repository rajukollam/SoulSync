import 'package:flutter/material.dart';

import '../../services/auth_service.dart';

import '../chat/chat_screen.dart';
import '../memories/memories_screen.dart';
import '../partner/connect_partner_screen.dart';
import '../profile/profile_screen.dart';

import '../../core/theme/app_gradients.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/widgets/floating_nav_bar.dart';

import 'widgets/music_card.dart';
import 'widgets/quote_card.dart';
import 'widgets/relationship_card.dart';
import 'widgets/stats_section.dart';
import 'widgets/welcome_header.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AuthService _authService = AuthService();

  int selectedIndex = 0;

  final List<Widget> pages = const [
    HomePage(),
    ChatScreen(),
    MemoriesScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      appBar: AppBar(
        title: const Text("SoulSync ❤️"),
        actions: [
          IconButton(
            tooltip: "Logout",
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await _authService.signOut();
            },
          ),
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: FloatingNavBar(
        currentIndex: selectedIndex,
        onTap: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = AuthService().currentUser;

    return Container(
      decoration: const BoxDecoration(
        gradient: AppGradients.background,
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: AppSpacing.screenPadding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const WelcomeHeader(),

              const SizedBox(height: AppSpacing.lg),

              Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.person),
                  ),
                  title: const Text(
                    "Logged in as",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    user?.email ?? "Unknown User",
                  ),
                ),
              ),

              const SizedBox(height: AppSpacing.lg),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.favorite),
                  label: const Text("Connect Partner ❤️"),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ConnectPartnerScreen(),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: AppSpacing.lg),

              const RelationshipCard(),

              const SizedBox(height: AppSpacing.lg),

              const StatsSection(),

              const SizedBox(height: AppSpacing.lg),

              const QuoteCard(),

              const SizedBox(height: AppSpacing.lg),

              const MusicCard(),

              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }
}