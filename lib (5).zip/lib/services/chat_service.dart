import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/message_model.dart';

/// Firebase access for the one private conversation shared by a connected pair.
class ChatService {
  ChatService({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  String getChatId(String firstUserId, String secondUserId) {
    final userIds = [firstUserId, secondUserId]..sort();
    return '${userIds.first}_${userIds.last}';
  }

  Stream<List<MessageModel>> messages({
    required String currentUserId,
    required String partnerId,
  }) {
    return _messagesReference(currentUserId, partnerId)
        .orderBy('sentAt', descending: true)
        .limit(100)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map(MessageModel.fromFirestore)
            .toList(growable: false));
  }

  /// Creates the chat metadata and message together, preventing orphan threads.
  Future<void> sendMessage({
    required String currentUserId,
    required String partnerId,
    required String text,
  }) async {
    final trimmedText = text.trim();
    if (trimmedText.isEmpty) return;

    final chatReference = _chatReference(currentUserId, partnerId);
    final messageReference = chatReference.collection('messages').doc();
    final batch = _firestore.batch();

    batch.set(chatReference, {
      'members': [currentUserId, partnerId]..sort(),
      'lastMessage': trimmedText,
      'lastMessageAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    batch.set(messageReference, {
      'senderId': currentUserId,
      'text': trimmedText,
      'sentAt': FieldValue.serverTimestamp(),
      'seen': false,
    });
    await batch.commit();
  }

  /// Marks only received messages as read. Calling this repeatedly is safe.
  Future<void> markReceivedMessagesSeen({
    required String currentUserId,
    required String partnerId,
    required List<MessageModel> messages,
  }) async {
    final unread = messages.where(
      (message) => !message.seen && message.senderId != currentUserId,
    );
    if (unread.isEmpty) return;

    final batch = _firestore.batch();
    final reference = _messagesReference(currentUserId, partnerId);
    for (final message in unread) {
      batch.update(reference.doc(message.id), {'seen': true});
    }
    await batch.commit();
  }

  DocumentReference<Map<String, dynamic>> _chatReference(
    String currentUserId,
    String partnerId,
  ) =>
      _firestore.collection('chats').doc(getChatId(currentUserId, partnerId));

  CollectionReference<Map<String, dynamic>> _messagesReference(
    String currentUserId,
    String partnerId,
  ) =>
      _chatReference(currentUserId, partnerId).collection('messages');
}
